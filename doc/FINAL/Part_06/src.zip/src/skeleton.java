import java.io.IOException;


public class skeleton {
	
	public skeleton()
	{
		System.out.println("skeleton()-Begin");

		int temp;
		City C=new City();
		
		temp=1;
		while(temp!=0)
		{ 
			System.out.println("mi t�rt�nik? 0:v�ge 1:move");
			try
			{
				temp=System.in.read();
				temp=temp-48;
				System.in.skip(System.in.available());
				if (temp==1)
				{
					C.step();
				}
			}
			catch(IOException e)
			{
				System.out.println("Hib�s bemenet");			
			}	
			
		}
		
		
		System.out.println("skeleton()-End");
	}
	
}
