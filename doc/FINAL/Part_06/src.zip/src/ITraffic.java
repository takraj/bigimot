public interface ITraffic {

	/**
	 * Forgalmi jelz�seket �sszefog� interf�sz
	 *  
	 */
	void step();

	int getState();

}