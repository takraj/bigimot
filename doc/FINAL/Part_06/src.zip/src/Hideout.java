public class Hideout extends Building {

	/**
	 * Az oszt�ly jelenleg nem p�ld�nyosul meg
	 *  
	 */
	public Hideout(RoadBlock keeper) {
		super(keeper);
	}

	public int getRole() {
		throw new UnsupportedOperationException();
	}

}