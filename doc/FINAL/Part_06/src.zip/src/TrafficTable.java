public class TrafficTable implements ITraffic {

	private int state;

	public TrafficTable()
	{
		System.out.println("TrafficTable()-Begin");
		System.out.println("TrafficTable()-End");
	
	}

	@Override
	public int getState() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void step() {
		// TODO Auto-generated method stub
		
	}

}