
public class game {
	public static void main(String args[])
	{
	  skeleton S = new skeleton();
	}

}
