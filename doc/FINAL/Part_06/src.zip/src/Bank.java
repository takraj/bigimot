public class Bank extends Building {

	/**
	 * Az oszt�ly jelenleg nincs haszn�lva
	 *  
	 */

	public Bank(RoadBlock keeper) {
		super(keeper);
	}

	public int getRole() {
		throw new UnsupportedOperationException();
	}

}