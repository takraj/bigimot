public class TrafficSign implements ITraffic {

	private int state;

	public TrafficSign()
	{
		System.out.println("TrafficSign()-Begin");
		System.out.println("TrafficSign()-End");
	
	}
	
	
	@Override
	public int getState() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void step() {
		// TODO Auto-generated method stub
		
	}

}